


public class MusicShuffleTester{
  public static void main(String[] a){
     new MusicShuffle();
  }
}